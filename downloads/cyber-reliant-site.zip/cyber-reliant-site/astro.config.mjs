import { defineConfig } from 'astro/config';
import node from '@astrojs/node';
export default defineConfig({
  output: 'server',
  adapter: node({ mode: 'standalone' }),
  server: { port: 4321 },
  security: { allowedDomains: [{ hostname: 'localhost' }, { hostname: '127.0.0.1' }] },
  devToolbar: { enabled: false },
});
